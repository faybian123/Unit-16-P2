﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unit_16_P2
{
    class Program
    {
        static void Main(string[] args)
        {


            // Declare variables and then initialize to zero.
            int num1 = 0; int num2 = 0;

            // Display title as the C# console calculator app.
            Console.WriteLine("Console Calculator in C#\r");
            // Displays the title as the C# console calculator app.
            Console.WriteLine("------------------------\n");

            // Ask the user to type the first number.
            Console.WriteLine("Type a number, and then press Enter");
            // This is what converts what is typed into an interger 
            num1 = Convert.ToInt32(Console.ReadLine());

            // Ask the user to type the second number.
            Console.WriteLine("Type another number, and then press Enter");
            // This is what converts what is typed into an interger.
            num2 = Convert.ToInt32(Console.ReadLine());

            // Ask the user to choose an option.
            Console.WriteLine("Choose an option from the following list:");
            //This is option 1.
            Console.WriteLine("\ta - Add");
            //This is option 2
            Console.WriteLine("\ts - Subtract");
            //This is option 3
            Console.WriteLine("\tm - Multiply");
            //This is option 4
            Console.WriteLine("\td - Divide");
            //This is displayed when none of the options from 1 to 4 are chosen
            Console.Write("Your option? ");

            // Use a switch statement to do the math.
            switch (Console.ReadLine())
            {
                //this is the first data storage 
                case "a":
                    //this is what carries out the addition equasion
                    Console.WriteLine($"Your result: {num1} + {num2} = " + (num1 + num2));
                    //This is what stops the looping process from carrying out all the calculations 
                    break;
                //this is the second data storage 
                case "s":
                    //this is what carries out the subtraction equasion
                    Console.WriteLine($"Your result: {num1} - {num2} = " + (num1 - num2));
                    //This is what stops the looping process from carrying out all the calculations 
                    break;
                //this is the third data storage 
                case "m":
                    //this is what carries out the multiplication equasion
                    Console.WriteLine($"Your result: {num1} * {num2} = " + (num1 * num2));
                    //This is what stops the looping process from carrying out all the calculations 
                    break;
                //this is the fourth data storage 
                case "d":
                    //this is what carries out the Division equasion
                    Console.WriteLine($"Your result: {num1} / {num2} = " + (num1 / num2));
                    //This is what stops the looping process from carrying out all the calculations 
                    break;
            }
            // Wait for the user to respond before closing.
            Console.Write("Press any key to close the Calculator console app...");
            //This is what allows the page with the information to stay open until the enter key is pressed
            Console.ReadKey();







        }
    }
}
